Gray Ellegance template 1.0
by Felipe D�rio
http://flipdarius.googlepages.com/
_________________________________________

This work is licensed under a
Creative Commons Attribution 2.5 License.
[http://creativecommons.org/licenses/by/2.5/]

This means you may use it for any purpose,
and make any changes you like.
All I ask is that you mantain the phrase 
"Designed by Felipe D�rio." and the link back 
to http://flipdarius.googlepages.com/ in your 
footer/credits.

Are you using this template? Send me an email
(including a link or picture if available) to
orangax@gmail.com

Any other questions about this template please
contact orangax@gmail.com